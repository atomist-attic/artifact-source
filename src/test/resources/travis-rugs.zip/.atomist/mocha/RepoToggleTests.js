Object.defineProperty(exports, "__esModule", { value: true });
var RepoToggle_1 = require("../handlers/command/RepoToggle");
require("mocha");
var assert = require("power-assert");
describe("repoToggle", function () {
    function checkPlan(enable) {
        var enabled = ((enable) ? "en" : "dis") + "abled";
        var enabling = ((enable) ? "En" : "Dis") + "abling";
        var fn = "travis-" + ((enable) ? "en" : "dis") + "able-repo";
        var org = ".com";
        var repo = "double-nickels-on-the-dime";
        var owner = "minutemen";
        var plan = RepoToggle_1.repoToggle(enable, org, repo, owner);
        assert(plan.messages.length === 1);
        assert(plan.messages[0].kind === "response");
        var msg = plan.messages[0];
        assert(msg.body === enabling + " Travis CI builds for " + owner + "/" + repo + "...");
        assert(plan.instructions.length === 1);
        var resp = plan.instructions[0];
        var instruction = resp.instruction;
        assert(instruction.kind === "execute");
        assert(instruction.name === fn);
        var params = instruction.parameters;
        assert(params.owner === owner);
        assert(params.repo === repo);
        assert(params.org === org);
        var successParams = resp.onSuccess.parameters;
        assert(successParams.msg === "Successfully " + enabled + " " + owner + "/" + repo + " on Travis CI");
    }
    it("should return a plan to enable a repo", function () {
        checkPlan(true);
    });
    it("should return a plan to disable a repo", function () {
        checkPlan(false);
    });
});
//# sourceMappingURL=RepoToggleTests.js.map