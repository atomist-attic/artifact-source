var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var Handlers_1 = require("@atomist/rug/operations/Handlers");
var PathExpression_1 = require("@atomist/rug/tree/PathExpression");
var Built = (function () {
    function Built() {
    }
    Built.prototype.handle = function (event) {
        var build = event.root;
        var plan = new Handlers_1.EventPlan();
        var repo = build.repo.name;
        var owner = build.repo.owner;
        var cid = "commit_event/" + owner + "/" + repo + "/" + build.commit.sha;
        var message = new Handlers_1.LifecycleMessage(build, cid);
        if (build.status === "passed") {
            try {
                var tag = build.commit.tags;
                if (tag.length > 0) {
                    message.addAction({
                        label: "Release",
                        instruction: {
                            kind: "command",
                            name: { group: "atomist", artifact: "github-rugs", name: "CreateGitHubRelease" },
                            parameters: {
                                owner: build.repo.owner,
                                repo: build.repo.name,
                                tag: tag[0].name,
                                message: "Release created by TravisBuilds",
                            },
                        },
                    });
                }
            }
            catch (e) {
                console.log(e.message);
            }
        }
        else if (build.status === "failed" || build.status === "broken") {
            try {
                if (build.commit.author != null && build.commit.author.person != null) {
                    var body = "Travis CI build `#" + build.name + "` of `" + owner + "/" + repo + "` failed after" +
                        (" your last commit `" + build.commit.sha + "`: " + build.buildUrl);
                    var address = new Handlers_1.UserAddress(build.commit.author.person.chatId.id);
                    plan.add(new Handlers_1.DirectedMessage(body, address));
                }
            }
            catch (e) {
                console.log(e.message);
            }
            message.addAction({
                label: "Restart",
                instruction: {
                    kind: "command",
                    name: "RestartTravisBuild",
                    parameters: {
                        buildId: build.id,
                        org: build.repo.owner,
                    },
                },
            });
        }
        plan.add(message);
        return plan;
    };
    return Built;
}());
Built = __decorate([
    Decorators_1.EventHandler("TravisBuilds", "Handle build events", new PathExpression_1.PathExpression("/Build\n            [@provider='travis']\n            [/commit::Commit()\n                [/author::GitHubId()[/person::Person()/chatId::ChatId()]?]\n                [/tags::Tag()]?]\n            [/repo::Repo()/channels::ChatChannel()]\n            [/push::Push()\n                [/commits::Commit()/author::GitHubId()\n                    [/person::Person()/chatId::ChatId()]?]\n                [/repo::Repo()]]")),
    Decorators_1.Tags("ci", "travis")
], Built);
exports.built = new Built();
var PRBuild = (function () {
    function PRBuild() {
    }
    PRBuild.prototype.handle = function (event) {
        var build = event.root;
        var pr = build.pullRequest;
        var cid = "pr_event/" + pr.repo.owner + "/" + pr.repo.name + "/" + pr.number;
        var message = new Handlers_1.LifecycleMessage(build, cid);
        if (build.status === "passed") {
            message.addAction({
                label: "Merge",
                instruction: {
                    kind: "command",
                    name: { group: "atomist", artifact: "github-rugs", name: "MergeGitHubPullRequest" },
                    parameters: {
                        issue: pr.number,
                    },
                },
            });
        }
        else if (build.status === "failed" || build.status === "broken") {
            message.addAction({
                label: "Restart Build",
                instruction: {
                    kind: "command",
                    name: "RestartTravisBuild",
                    parameters: {
                        buildId: build.id,
                        org: build.repo.owner,
                    },
                },
            });
        }
        return Handlers_1.EventPlan.ofMessage(message);
    };
    return PRBuild;
}());
PRBuild = __decorate([
    Decorators_1.EventHandler("TravisBuildsPrs", "Handle build events from pull-requests", new PathExpression_1.PathExpression("/Build\n            [@provider='travis']\n            [/repo::Repo()/channels::ChatChannel()]\n            [/pullRequest::PullRequest()\n                [/author::GitHubId()[/person::Person()/chatId::ChatId()]?]\n                [/merger::GitHubId()[/person::Person()/chatId::ChatId()]?]?\n                [/commits::Commit()/author::GitHubId()[/person::Person()/chatId::ChatId()]?]\n                [/repo::Repo()]]")),
    Decorators_1.Tags("ci", "travis")
], PRBuild);
exports.prBuilt = new PRBuild();
//# sourceMappingURL=Build.js.map