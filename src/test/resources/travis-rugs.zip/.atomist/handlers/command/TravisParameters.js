Object.defineProperty(exports, "__esModule", { value: true });
exports.TravisParameters = {
    APIEndpoint: {
        displayName: "Travis API Endpoint",
        description: "Travis .com or .org API to hit",
        pattern: "^\\.(com|org)$",
        validInput: "either \".org\" or \".com\"",
        minLength: 4,
        maxLength: 4,
        required: true,
    },
};
//# sourceMappingURL=TravisParameters.js.map