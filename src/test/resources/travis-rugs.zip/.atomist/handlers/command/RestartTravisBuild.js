var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var Handlers_1 = require("@atomist/rug/operations/Handlers");
var CommonHandlers_1 = require("@atomist/rugs/operations/CommonHandlers");
var RestartBuild = (function () {
    function RestartBuild() {
        this.org = ".org";
    }
    RestartBuild.prototype.handle = function (ctx) {
        var plan = new Handlers_1.CommandPlan();
        var execute = {
            instruction: {
                kind: "execute",
                name: "restart-travis-build",
                parameters: this,
            },
        };
        plan.add(CommonHandlers_1.wrap(execute, "Successfully restarted Travis build " + this.buildId, this));
        return plan;
    };
    return RestartBuild;
}());
__decorate([
    Decorators_1.Parameter({ description: "The Travis CI build ID", pattern: "^.*$" }),
    __metadata("design:type", Number)
], RestartBuild.prototype, "buildId", void 0);
__decorate([
    Decorators_1.Parameter({ description: ".org or .com", pattern: "^\.com|\.org$" }),
    __metadata("design:type", String)
], RestartBuild.prototype, "org", void 0);
RestartBuild = __decorate([
    Decorators_1.CommandHandler("RestartTravisBuild", "Restart a Travis CI build"),
    Decorators_1.Tags("travis-ci", "ci"),
    Decorators_1.Secrets("github://user_token?scopes=repo"),
    Decorators_1.Intent("restart build", "restart travis build")
], RestartBuild);
exports.restartBuild = new RestartBuild();
//# sourceMappingURL=RestartTravisBuild.js.map