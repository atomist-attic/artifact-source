Object.defineProperty(exports, "__esModule", { value: true });
var Handlers_1 = require("@atomist/rug/operations/Handlers");
var CommonHandlers_1 = require("@atomist/rugs/operations/CommonHandlers");
function repoToggle(enable, org, repo, owner) {
    var fnName = (enable) ? "travis-enable-repo" : "travis-disable-repo";
    var action = (enable) ? "enabled" : "disabled";
    var actioning = action.replace("ed", "ing");
    var Actioning = actioning.charAt(0).toUpperCase() + actioning.slice(1);
    var plan = new Handlers_1.CommandPlan();
    var message = new Handlers_1.ResponseMessage(Actioning + " Travis CI builds for " + owner + "/" + repo + "...");
    plan.add(message);
    var execute = {
        instruction: {
            kind: "execute",
            name: fnName,
            parameters: { owner: owner, repo: repo, org: org },
        },
    };
    plan.add(CommonHandlers_1.wrap(execute, "Successfully " + action + " " + owner + "/" + repo + " on Travis CI", this));
    return plan;
}
exports.repoToggle = repoToggle;
//# sourceMappingURL=RepoToggle.js.map