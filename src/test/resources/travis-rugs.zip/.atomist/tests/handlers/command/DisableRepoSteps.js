Object.defineProperty(exports, "__esModule", { value: true });
var Core_1 = require("@atomist/rug/test/handler/Core");
Core_1.When("the DisableRepo is invoked", function (w) {
    var handler = w.commandHandler("DisableRepo");
    w.invokeHandler(handler, {
        org: ".com",
        owner: "purple",
        repo: "rain",
    });
});
//# sourceMappingURL=DisableRepoSteps.js.map