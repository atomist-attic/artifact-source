Object.defineProperty(exports, "__esModule", { value: true });
var Core_1 = require("@atomist/rug/test/handler/Core");
Core_1.Given("nothing", function (w) { return; });
var testOwner = "uncle";
var testRepo = "tupelo";
Core_1.When("the EnableRepo is invoked", function (w) {
    var handler = w.commandHandler("EnableRepo");
    w.invokeHandler(handler, {
        org: ".org",
        owner: testOwner,
        repo: testRepo,
    });
});
Core_1.When("the EnableRepo is invoked with a bad parameter", function (w) {
    var handler = w.commandHandler("EnableRepo");
    w.invokeHandler(handler, {
        org: ".not",
        owner: testOwner,
        repo: testRepo,
    });
});
Core_1.Then("a message is sent", function (w) {
    return w.plan().messages.length === 1;
});
Core_1.Then("there is an instruction", function (w) {
    return w.plan().instructions.length === 1;
});
//# sourceMappingURL=EnableRepoSteps.js.map