# Atomist Default Spring REST Template

*Templates get you running and updated with best-practices, fast!*

## Description

The canonical Atomist-supplied Spring REST Microservice template. Project templates are used in code generation and maintenance across your microservices.

See https://github.com/atomisthq/product/wiki/Project-Operations
