(ns com.atomist.sample.t_core
  (:require [midje.sweet :refer :all])
  (:require [com.atomist.sample.core :as core]))


(facts "about core")